﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14_Практическая_алгоритмизация
{
    internal class Class1
    {
        public string name;
        public string surname;
        public string name2;
        public double age;
        public double weight;
        public Class1(string name, string surname, string name2, double age, double weight)
        {
            this.name = name;
            this.surname = surname;
            this.name2 = name2;
            this.age = age;
            this.weight = weight;
        }
    }
}
