﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _14_Практическая_алгоритмизация
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Queue<Class1> queue = new Queue<Class1>();
        Queue<Class2> queue2 = new Queue<Class2>();
        public static bool IsBalanced(string expression)
        {
            Stack<char> stack = new Stack<char>();

            foreach (char c in expression)
            {
                if (c == '(')
                {
                    stack.Push(c);
                }
                else if (c == ')')
                {
                    if (stack.Count == 0 || stack.Peek() != '(')
                    {
                        return false;
                    }

                    stack.Pop();
                }
            }

            return stack.Count == 0;
        }
        public static int FindExtraBracket(string expression)
        {
            Stack<char> stack = new Stack<char>();
            int position = -1;

            for (int i = 0; i < expression.Length; i++)
            {
                char c = expression[i];

                if (c == '(')
                {
                    stack.Push(c);
                }
                else if (c == ')')
                {
                    if (stack.Count == 0 || stack.Peek() != '(')
                    {
                        position = i + 1;
                        break;
                    }

                    stack.Pop();
                }
            }

            return position;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown1.Value);
            Stack<int> numbers = new Stack<int>();
            listBox1.Items.Add($"Верхний элемент:{n}");
            for (int i = 1; i <= n; i++)
            {
                numbers.Push(i);
            }
            listBox1.Items.Add($"размерность стека:{numbers.Count}");
            listBox1.Items.Add($"содержимое");
            for (int i = 1; i <= n; i++)
            {
                int n1 = numbers.Pop();
                listBox1.Items.Add(n1);
            }
            listBox1.Items.Add($"новая размерность {numbers.Count}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string expression = textBox1.Text;

            if (IsBalanced(expression))
            {
                label1.Text = "Скобки сбалансированы";
            }
            else
            {
                label1.Text = "Возможно лишняя ( скобка в позиции: " + FindExtraBracket(expression) + ")";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                listBox2.Items.Clear();
                int n = int.Parse(textBox2.Text);
                if (n > 1)
                {
                    Queue<int> collection = new Queue<int>(n);
                    for (int i = 1; i <= n; i++)
                    {
                        collection.Enqueue(i);
                    }
                    label2.Text = $"Размерность очереди = {collection.Count}\nВерхний элемент очереди = {collection.Peek()}";
                    for (int i = 1; i <= n; i++)
                    {
                        listBox2.Items.Add(collection.Dequeue());
                    }
                    label2.Text = $"Новая размерность очереди = {collection.Count}";
                }
                else
                    MessageBox.Show("Введите положительное число, больше единицы");
            }
            catch
            {
                MessageBox.Show("Неверный формат данных");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists("People.txt"))
                {
                    listBox3.Items.Clear();
                    StreamReader sr = File.OpenText("People.txt");
                    while (!sr.EndOfStream)
                    {
                        string[] array = new string[5];
                        array = sr.ReadLine().Split(' ');
                        Class1 man = new Class1(array[0], array[1], array[2], double.Parse(array[3]), double.Parse(array[4]));
                        queue.Enqueue(man);
                    }
                    sr.Close();
                    int n = queue.Count;
                    for (int i = 0; i < n; i++)
                    {
                        if (queue.ElementAt(i).age < 40)
                            listBox3.Items.Add($"{queue.ElementAt(i).name} {queue.ElementAt(i).surname} {queue.ElementAt(i).name2} {queue.ElementAt(i).age} {queue.ElementAt(i).weight}");
                    }
                    for (int i = 0; i < n; i++)
                    {
                        if (queue.ElementAt(i).age >= 40)
                            listBox3.Items.Add($"{queue.ElementAt(i).name} {queue.ElementAt(i).surname} {queue.ElementAt(i).name2} {queue.ElementAt(i).age} {queue.ElementAt(i).weight}");
                    }
                    queue.Clear();
                }
                else
                    MessageBox.Show("Файл для считывания информации отсутствует");
            }
            catch
            {
                MessageBox.Show("Неверный формат данных в исходном файле");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists("People1.txt") && File.Exists("People2.txt"))
                {
                    listBox4.Items.Clear();
                    StreamReader sr = File.OpenText("People1.txt");
                    while (!sr.EndOfStream)
                    {
                        string[] array = new string[3];
                        array = sr.ReadLine().Split(' ');
                        Class2 man = new Class2();
                        man.name = array[0];
                        man.surname = array[1];
                        man.name2 = array[2];
                        queue2.Enqueue(man);
                    }
                    sr.Close();
                    StreamReader sr1 = File.OpenText("People2.txt");
                    for (int i = 0; i < queue2.Count; i++)
                    {
                        string[] array = new string[2];
                        array = sr1.ReadLine().Split(' ');
                        queue2.ElementAt(i).age = double.Parse(array[0]);
                        queue2.ElementAt(i).weight = double.Parse(array[1]);
                    }
                    sr1.Close();
                    var sortedPeople1 = from p in queue2
                                        orderby p.name, p.age
                                        select p;
                    foreach (var p in sortedPeople1)
                        listBox4.Items.Add($"{p.name} {p.surname} {p.name2} {p.age} {p.weight}");
                    queue2.Clear();
                }
                else
                    MessageBox.Show("1 или 2 файла для считывания информации отсутствует(ют)");
            }
            catch
            {
                MessageBox.Show("Неверный формат данных в исходном файле");
            }
        }
    }
}
